#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 31 10:09:14 2022

@author: Thibault Hiron-Bédiée, agrégation spéciale 2022, préparation Rennes 1
"""

#-----------------------------------------------------------------------------
# Tracé d'un diagramme espace temps pour un train traversant un tunnel (LP26)
#-----------------------------------------------------------------------------

# Bibliothèques utilisées

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as anim                   # pour l'animation
from matplotlib.widgets import RadioButtons, Slider, CheckButtons   # et pour l'interface.
from matplotlib.patches import Rectangle
# format vectoriel par défaut des images
from IPython.display import set_matplotlib_formats
set_matplotlib_formats('svg')

"""
Déclaration des classes utilisées
"""
            
"""
Déclaration des fonctions
"""
    
"""
Fonction principale : tracé d'un diagramme de Minkovski interactif
"""


def plot_ani():
    # Tracé des axes du référentiel du tunnel
    fig = plt.figure(constrained_layout=True, figsize=(8,5))
    gs = fig.add_gridspec(ncols=8, nrows=6)
    ax0 = fig.add_subplot(gs[0:5,0:5])
    ax1 = fig.add_subplot(gs[1:4,5:8])
        
#    fig, ax=plt.subplots(2,1, gridspec_kw={'height_ratios': [5, 1]})
    axcolor = 'white'
    axN = plt.axes([0.62, .9, .33, 0.03], facecolor=axcolor)
    sl_axN = Slider(axN, 'N', 1, 2*6+1, valinit=11, valstep=2)  
    N=sl_axN.val                       #Slider pour modifier le temps
    axtheta = plt.axes([0.62, 0.85, .33, 0.03], facecolor=axcolor)
    sl_axtheta = Slider(axtheta, r'$\theta$', 0.9, 1.1, valinit=1, valstep=0.01)
    
    def plot_ini():
        # Zone de tracé du diagramme
        ax0.set_xlim(xmin0, xmax0)
        ax0.set_ylim(ymin0, ymax0)
        ax0.set_frame_on(False)
        ax0.xaxis.set_visible(False)
        ax0.yaxis.set_visible(False)
    
        # Tracé des axes du référentiel du tunnel
        # Axe x
        ax0.arrow(xmin-.4, 0,xmax-xmin+.8, 0, shape='full', lw=.75, length_includes_head=True, head_width=.25, color='black')
        ax0.text(xmax+.4, .2, r'$\theta$', color='black', va = "bottom", ha="right")
        # Axe B
        ax0.arrow(0, ymin-.4, 0, ymax-ymin+.4, shape='full', lw=.75, length_includes_head=True, head_width=.25, color='black')
        ax0.text(.2, ymax, "$B$", color='black', va = "top", ha="left")
    
    def visu_plot(N,theta0):
        ax1.clear()
        # Zone de tracé de la visualisation du train et du tunnel
        ax1.set_xlim(-3, 3)
        ax1.set_ylim(-3, 4)
        ax1.set_frame_on(False)
        ax1.xaxis.set_visible(False)
        ax1.yaxis.set_visible(False)
        ax1.set_aspect('equal')
        
        # Dessiner le stator
        stator1 = plt.Circle((0, 0), 3, color='grey', fill=True)
        stator2 = plt.Circle((0, 0), 1.5, color='white', fill=True)
        ax1.add_patch(stator1)
        ax1.add_patch(stator2)
        
        # Dessiner le rotor
        rotor = plt.Circle((0, 0), 1, color='grey', fill=True)
        ax1.add_patch(rotor)
        
        # Dessiner les encoches
        for i in range (0,N):
            ts = ax1.transData
            coords = ts.transform([.05, -1.9])
            print(coords)
            # Encoches supérieures
            tr = mpl.transforms.Affine2D().rotate_around(coords[0],coords[1],(i-(N-1)/2)*theta0+np.pi/2)
            encoche1=patches.Rectangle((1.5,-.1),0.2,0.2,color='white',transform=ts+tr)
            ax1.add_patch(encoche1)
            fil1=patches.Circle((1.63,0),radius=0.1,color='k',linewidth=0.5,fill=False,transform=ts+tr)
            fil2=patches.Circle((1.63,0),radius=0.03,color='k',fill=True,transform=ts+tr)
            ax1.add_patch(fil1)
            ax1.add_patch(fil2)
            # Encoches inférieures
            tr = mpl.transforms.Affine2D().rotate_around(coords[0],coords[1],(i-(N-1)/2)*theta0-np.pi/2)
            encoche1=patches.Rectangle((1.5,-.1),0.2,0.2,color='white',transform=ts+tr)
            ax1.add_patch(encoche1)
            fil1=patches.Circle((1.63,0),radius=0.1,color='k',linewidth=0.5,fill=False,transform=ts+tr)
            fil2a= patches.Rectangle((1.53, 0), 0.2, 0, color='k', linewidth=0.5, transform=ts+tr)
            fil2b= patches.Rectangle((1.63, -.1), 0, 0.2, color='k', linewidth=0.5, transform=ts+tr)
            ax1.add_patch(fil1)
            ax1.add_patch(fil2a)
            ax1.add_patch(fil2b)
        
        
    def champ_1(theta,theta0):
        x= theta-theta0
        for i in range (0,300):
            if x[i]<-4.712 or x[i]>-1.57 and x[i]<1.57 or x[i]> 4.712:
                x[i]=5
            else:
                x[i]=-5
        return x
        
    def champ_N(theta,N,theta0):
        val=0
        for i in range (0,N):
            val=val+champ_1(theta,(i-(N-1)/2)*theta0)/(N)
        return val
        
    def trace_champ(N,theta0):
        # Calcul des coordonnées
        x=np.linspace(xmin,xmax,300)
        ax0.plot(x,champ_N(x,N,theta0))
        ax0.plot(x,5*np.cos(x),'r-')

    def update_N(val): 
        N = sl_axN.val
        theta0=2.63/(N+1)*sl_axtheta.val
    #    theta0=np.pi/(4*N+1)
        x=np.linspace(xmin,xmax,300)
        ax0.lines[0].set_data(x,champ_N(x,N,theta0))
        visu_plot(N,theta0)
        
    def update_theta(val):
        N = sl_axN.val
        theta0=2.63/(N+1)*sl_axtheta.val
    #    theta0=np.pi/(4*N+1)
        x=np.linspace(xmin,xmax,300)
        ax0.lines[0].set_data(x,champ_N(x,N,theta0))
        visu_plot(N,theta0)

    
    """
    Initialisation
    """
    
    # Coordonnées du graphe (référentiel du tunnel)
    xmin=-5
    ymin=-5
    xmax=5
    ymax=5
    # Coordonnées avec les marges
    margin=1
    xmin0=xmin-margin
    ymin0=ymin-margin
    xmax0=xmax+margin
    ymax0=ymax+margin
        
    plot_ini()
    N=sl_axN.val
    theta0=2.63/(N+1)*sl_axtheta.val
    trace_champ(N,theta0)
    # trace_event(beta,normalize)
    # proj_visu(ct, beta, referentiel)
    visu_plot(N,theta0)
    
    sl_axN.on_changed(update_N)
    sl_axtheta.on_changed(update_theta)
   
    # Tracé de la figure
    plt.show()

if __name__ =='__main__':
   plot_ani()