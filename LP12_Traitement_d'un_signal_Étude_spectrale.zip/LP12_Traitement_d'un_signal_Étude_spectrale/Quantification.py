#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  3 17:05:42 2022

@author: thibault
"""


## Importation des bibliotheques
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
from numpy import pi

## Creation de la fenetre

fig, ax = plt.subplots()
plt.subplots_adjust(left=0.2, bottom=0.2)         # dimensions du graphique

t = np.arange(-1, 1, 0.001)    # temps allant de -2 s Ã  4s par pas de 0.01s (sur trois periodes)
t1 = np.linspace(-1,1,101)
# Creation de la courbe initiale (avec la serie de Fourier Ã  un terme)
def quantifie(f,N):
    return np.floor(f*N)/N
quant_vect=np.vectorize(quantifie)

N0=0                                                # initialisation Ã  1 le nombre de composantes de la serie de Fourier
l, = plt.plot(t, np.sin(2*pi*t), lw=1, color='red')         # courbe Ã  tracer i en fonction de omega
lq, = plt.plot(t1,quant_vect(np.sin(2*pi*t1),2048), lw=.8, color='blue')
plt.axis([-1, 1, -1.2, 1.2])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Temps (s)")                     # titre de l'axe des abscisses
plt.ylabel("Amplitude du signal (V)")                               # titre de l'axe des ordonnees
plt.title("Numérisation d'un signal") 
plt.grid(True)                                          # quadrille le graphique


## Ajout des barres de changement de valeur des variables initiales
axcolor = 'lightgoldenrodyellow'                            # couleur des barres
axN = plt.axes([0.25, 0.02, 0.65, 0.03], facecolor=axcolor)    # localisation de la barre pour N
ioN = Slider(axN,"Niveaux/V",0,11,valinit=11,valstep=1,valfmt='2^'+'%0.0f')
axf = plt.axes([0.25, 0.06, 0.65, 0.03], facecolor=axcolor)    # localisation de la barre pour N
iof = Slider(axf,"Échantillons'/s",1,50,valinit=50,valstep=.1,valfmt='%0.1f')

## Definition de la fonction qui permet de reinitialiser les valeurs initiales par celle choisie Ã  la barre
def update(val):
    N = 2**ioN.val
    ech = iof.val                                           # prend la valeur de la barre pour N
    t1 = np.arange(-1,1,1/ech)
    lq.set_data(t1,quant_vect(np.sin(2*pi*t1),N))    # ressort le nouveau profil de resonance
    fig.canvas.draw_idle()                                  # redessine la courbe
ioN.on_changed(update)                                      # affiche Ã  cÃ´te de la barre la valeur de N
iof.on_changed(update)                                      # affiche Ã  cÃ´te de la barre la valeur de N


## Definition d'un bouton reset
resetax = plt.axes([0.03, 0.9, 0.1, 0.04])
button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')

def reset(event):
    ioN.reset()
    iof.reset()
button.on_clicked(reset)

plt.show()