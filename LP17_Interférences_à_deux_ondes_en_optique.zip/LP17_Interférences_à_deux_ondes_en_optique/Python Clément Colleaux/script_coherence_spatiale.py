# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 19:43:47 2019

@author: Laura
"""

import numpy as np
from numpy import loadtxt
import random

import matplotlib as mpl
import matplotlib.pyplot as plt


#%% Largeur de cohérence spatiale
b= np.linspace(0, 5, 10**3) #b représente directement le facteur normalisé ab / Llambda.
gamma= np.sinc(b)

plt.figure()
plt.plot(b, gamma,'--',  label=r'$\Gamma$', color='black')
plt.plot(b, np.abs(gamma), label=r'$C=|\Gamma|$', color='C1')
plt.legend()

plt.xlabel(r'$\frac{ab}{\lambda L} $')
plt.ylabel(r'$\Gamma$')

plt.ylim(-0.25, 1.02)
y=[-0.4, 1.5]
y=[0, 0.5, 1, 1.5]
plt.savefig('coherence_spatialle_contraste.png')

plt.scatter(y, np.sinc(y), color='black', zorder=100)

# plt.savefig('coherence_spatialle_contraste_dots.png')
#plt.plot([108*1e-3, 108*1e-3], y, '--', color='C0')
#plt.plot([30*1e-3, 30*1e-3], y, '--', color='C7')
#plt.plot([75*1e-3, 75*1e-3], y, '--', color='C2')

plt.show()


#%%Intensite sur ecran
x= np.linspace(0, 6, 100)

amplitude = np.array([np.ones(np.shape(x)[0])+np.sinc(b0)*np.cos(2 * np.pi * x) for b0 in b])

valeurs=['0', '0.5', '1', '1.5']
Num=[0, np.where(b>0.5)[0][0], np.where(b>1)[0][0], np.where(b>1.5)[0][0]]
n= len(Num)

plt.figure()
for k in range(len(Num)):
    num=Num[k]
    M= np.zeros((150,x.shape[0] ))
    for i in range(np.shape(M)[0]):
        M[i, :]=amplitude[num]/2
    print(num)
    plt.subplot(n, 1, k+1)
    plt.imshow(M, cmap= 'gray', vmin=0, vmax=1)
    plt.yticks([])
#    plt.xticks([0, 200, 400, 600, 700, 800, 1e3], ['', '', '', '', '', ''])

    plt.ylabel(r'$\frac{ab}{\lambda L}=$'+valeurs[k], rotation =0, fontsize=8 )

    ax = plt.gca()
    ax.yaxis.set_label_coords(-0.15, 0.15)

plt.xticks([0, 200, 400, 600, 800, 1000], [0, 1, 2, 3, 4, 5])
plt.text(-1, -1000, r'$\Gamma$')
plt.xlabel(r'$\frac{ax}{\lambda D}$')
# plt.savefig('coherence_spatialle_intensite_ecran.png')

plt.show()