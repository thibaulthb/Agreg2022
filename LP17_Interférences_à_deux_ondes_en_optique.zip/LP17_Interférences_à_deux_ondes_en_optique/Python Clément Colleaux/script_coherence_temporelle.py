import numpy as np
import matplotlib.pyplot as plt
import math


#%% Cohérence temporelle, addition des intensités pour deux longueurs d'ondes
delta= np.linspace(0, 6, 1000)

lamb1=0.51
lamb2=0.61
I1=1+ np.cos(2*np.pi*delta/ lamb1)
I2=1+ np.cos(2*np.pi*delta/ lamb2)
plt.figure()
plt.plot(delta, I1)
plt.plot(delta, I2)
plt.xlabel(r'$x$ (u.a.)')
plt.ylabel(r'$I(x)$')

plt.yticks([0, 2], [0, r'$I_0$'])
#plt.xticks([0, 2, 4, 6], [ '0', '', '', '', ''])

plt.savefig('coherence_temporelle_deux_ondes_intensite.png')
plt.figure()
plt.plot(delta, I1+I2, color='black')
plt.xlabel(r'$x$ (u.a.)')
plt.ylabel(r'$I(x)$')


plt.yticks([0, 2, 4], [0, r'$I_0$', r'$2I_0$'])

#plt.xticks([0, 2, 4, 6], [ '0', '', '', '', ''])

# plt.savefig('coherence_temporelle_deux_ondes_intesnite_totale.png')

plt.show()






#%% cohérence temporelle intensité sur l'écran pour lumière blanche sans couleurs

dnu=0.2 #Largeur fréquentielle de la source

f0 = (300000000)/ (0.000000009)
maxx0=0.1
fmax=0.2
wdnu= r'$\Delta \nu  / \nu_0 =0.2$'
a=100*1e-6
D=2
c=3*1e8



x0 = np.linspace(-0.15,0.15,1000)#1m
x= a*x0/ c/D *f0


s = np.ones(np.shape(x)[0])+np.sinc(dnu*x)*np.cos(2 * np.pi * x)

M= np.array([s for k in range(250)])
M0= np.array([np.ones(np.shape(x)[0])+np.cos(2 * np.pi * x) for k in range(250)])


fig=plt.figure()
plt.subplot(211)
plt.ylabel(r'$y$')
plt.imshow(M0, cmap='gray')
plt.yticks([])

#plt.xticks([0, 200, 400,500, 600, 700, 800, 1e3], ['', '', '','0', '', '', ''])

plt.subplot(212)
plt.ylabel(r'$y$')
plt.imshow(M, cmap='gray')
plt.xlabel(r'$\frac{ax \nu_0}{cD}$')
#plt.xticks([0, 200, 400,500, 600, 700, 800, 1e3], ['', '', '','0', '', '', ''])
plt.yticks([])


# plt.savefig('coherence_temporelle_intensite_ecran.png')

plt.show()

#%% Cohérence temporelle en lumière blanche, couleurs

delta= np.linspace(0, 0.000002, 1000)

Lamb= np.linspace(380, 750, 20)*0.000000001
color=( Lamb - np.min(Lamb)) /( np.max(Lamb)-np.min(Lamb))
def I(lamb):
    return 1+ np.cos(2*np.pi*delta/ lamb)

Itot=np.zeros((len(Lamb), len(delta)))
plt.figure()
k=-1
for lamb, c in zip(Lamb,color):
    k+=1
    plt.plot(delta*1e6, I(lamb), color=plt.cm.Spectral_r(c))
    Itot[k]= I(lamb)

Color_all=np.array([plt.cm.Spectral_r(color[Itot[:, k]==np.max(Itot[:,k])][0]) for k in range(len(delta))])
#plt.scatter(delta*1e6, np.sum(Itot, axis=0)/len(Lamb), c=Color_all, zorder=100)

plt.xlabel(r'$\frac{ax}{D} [\mu m]$')
plt.ylabel('I')

#plt.scatter(delta*1e6, np.sum(Itot, axis=0)/len(Lamb), c=Color_all, zorder=100)

# plt.savefig('coherence_temporelle_lumiere_blanche_couleurs.png')

plt.show()