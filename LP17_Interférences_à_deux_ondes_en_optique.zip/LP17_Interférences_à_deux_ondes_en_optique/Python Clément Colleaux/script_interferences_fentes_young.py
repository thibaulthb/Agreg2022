import numpy as np
import matplotlib.pyplot as plt
import math


#%% intensité et franges sur l'écran

a=0.0001
D=2
lamb=0.000000580



x0 = np.linspace(-0.04,0.04,1000)#1m
x= a*x0/ lamb/D

plt.figure()
plt.plot(x, np.ones(np.shape(x)[0])+np.cos(2 * np.pi * x) )
plt.xlabel(r'$\frac{ax}{\lambda D}$')
plt.ylabel('$I$')
plt.yticks([0, 1, 2], ['0', r'$I_0$', r'$2I_0$'])

plt.savefig('interferences_fente_young_intensite.png')


M0= np.array([np.ones(np.shape(x)[0])+np.cos(2 * np.pi * x) for k in range(500)])


fig=plt.figure()
plt.ylabel(r'$y$')
plt.imshow(M0, cmap='gist_heat', vmin=0, vmax=3)
#plt.yticks([])
plt.ylabel('$y$')
plt.yticks([])
plt.xlabel(r'$\frac{ax}{\lambda D}$')
plt.xticks([ 250, 500, 750], [ '-2', '0', '2'])

# plt.savefig('interferences_fente_young_image_ecran.png')

plt.show()