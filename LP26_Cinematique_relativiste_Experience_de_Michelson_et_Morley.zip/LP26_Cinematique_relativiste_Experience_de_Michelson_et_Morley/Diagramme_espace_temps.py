#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 19:30:45 2022

@author: Thibault Hiron-Bédiée, agrégation spéciale 2022, préparation Rennes 1
"""

#-----------------------------------------------------------------------------
# Tracé d'un diagramme espace temps pour un train traversant un tunnel (LP26)
#-----------------------------------------------------------------------------

# Bibliothèques utilisées

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as anim                   # pour l'animation
from matplotlib.widgets import RadioButtons, Slider   # et pour l'interface.
from matplotlib.patches import Rectangle
# format vectoriel par défaut des images
from IPython.display import set_matplotlib_formats
set_matplotlib_formats('svg')

# Les variables

#v = 1.617939e8
v = 1e8

# coordonnées du graphe (référentiel du tunnel)
xmin=0
ymin=0
xmax=25
ymax=20
# coordonnées avec les marges
margin=1
xmin0=xmin-margin
ymin0=ymin-margin
xmax0=xmax+margin
ymax0=ymax+margin

# Définition des paramètres
global VITESSE_LUMIERE
VITESSE_LUMIERE = 3e8   # vitesse de la lumière (m/s)

class objet:
    def __init__(self, L, xA):
        self.LONGUEUR = L
        self.queue = xA
        self.tete = xA+L
        self.visuA = xA/100
        self.visuB = (xA+L)/100
    
global train,tunnel
train = objet(475,0)             # longueur d'un TGV atlantique double (475 m)
tunnel = objet(400,1500)         # longueur du tunnel à traverser (m)
        
class evenement:
    def __init__(self, x,ct):
        self.x = x
        self.ct = ct
        self.x_prime = x
        self.ct_prime = ct
        
global A1,B1
A1 = evenement(0,0)
B1 = evenement(0,0)

def lorentz(a,b,beta):
    gamma=1/np.sqrt(1-beta**2)
    
    a_prime=gamma*(a-beta*b)
    return a_prime

# calcul des coordonnées pour le train et le tunnel et leur rencontre
def coords_ref_tunnel(beta):
    global tA1
    
    vitesse = beta*VITESSE_LUMIERE
    gamma=1/np.sqrt(1-beta**2)
    
    # définition des positions du tunnel et du train
    
    #calcul des coordonnées des événements A1 et B1 (dans le référentiel du tunnel)
    A1.x=tunnel.queue/100
    B1.x=tunnel.tete/100
    
    tA1=tunnel.queue/vitesse # instant pour lequel la queue du train entre dans le tunnel
    tB1=(tunnel.tete-train.LONGUEUR/gamma)/vitesse # instant pour lequel la tête du train sort du tunnel
    A1.ct=15
    B1.ct=A1.ct*tB1/tA1
    
def pos_visu(beta,temps,referentiel):
    vitesse = beta*VITESSE_LUMIERE
    gamma=1/np.sqrt(1-beta**2)
    if referentiel == 'Référentiel du tunnel' :
        train.visuA=(300+vitesse*temps*tA1)/100
        train.visuB=train.LONGUEUR/(100*gamma)
        tunnel.visuA=(300+tunnel.queue)/100
        tunnel.visuB=tunnel.LONGUEUR/100
    if referentiel == 'Référentiel du train' :
        train.visuA=300/100
        train.visuB=train.LONGUEUR/100
    #    tunnel.visuA=(300+lorentz(tunnel.queue-vitesse*temps*tA1, temps*tA1, -beta))/100
        tunnel.visuA=(tunnel.queue/gamma+300-vitesse*temps*tA1/gamma)/100
        tunnel.visuB=tunnel.LONGUEUR/(100*gamma)

# calcul des coordonnées des événements dans le référentiel du train
def coords_ref_train(beta):
    
    gamma=1/np.sqrt(1-beta**2)
    
    # calcul de la transformée de Lorentz pour les événements
    # coordonnées des événements (dans le référentiel du train selon x)
    A1.x_prime=lorentz(A1.x,A1.ct,beta)
    B1.x_prime=lorentz(B1.x,B1.ct,beta)
    # coordonnées des événements (dans le référentiel du train selon ct)
    A1.ct_prime=lorentz(A1.ct,A1.x,beta)
    B1.ct_prime=lorentz(B1.ct,B1.x,beta)

# calcul des longueurs
#L=B1.x-A1.x
#L_prime=np.sqrt((B1.x_prime-A1.x_prime)**2+(B1.ct_prime-A1.ct_prime)**2)*np.sqrt((1-beta**2)/(1+beta**2))
#print(L*100)
#print(L_prime*100)

def plot_ani():
    # Tracé des axes du référentiel du tunnel
    fig, ax=plt.subplots(2,1, gridspec_kw={'height_ratios': [5, 1]})
    axcolor = 'white'
    axct = plt.axes([0.15, 0.1, .3, 0.03], facecolor=axcolor)
    sl_axct = Slider(axct, 'ct', 0, 2.0*0.6, valinit=0., valstep=0.01)                         #Slider pour modifier le temps
    axv = plt.axes([0.15, 0.02, .3, 0.03], facecolor=axcolor)
    sl_axv = Slider(axv, chr(946), 0, 2.0*0.4, valinit=0.539, valstep=0.01)                         #Slider pour modifier le temps
    
    rax = plt.axes([0.57, 0.01, 0.33, 0.13])               #Boutons radio >>> modification du référentiel
    radio = RadioButtons(rax, ('Référentiel du tunnel', 'Référentiel du train'))
    
    """
    Initialisation
    """
    
    beta=sl_axv.val
    temps=sl_axct.val
    referentiel=radio.value_selected
    
    # Zone de tracé du diagramme
    ax[0].set_xlim(xmin0, xmax0)
    ax[0].set_ylim(ymin0, ymax0)
    ax[0].set_frame_on(False)
    ax[0].xaxis.set_visible(False)
    ax[0].yaxis.set_visible(False)
    
    # Zone de tracé de la visualisation du train et du tunnel
    ax[1].set_xlim(xmin0, xmax0)
    ax[1].set_ylim(ymin0, ymax0/20)
    ax[1].set_frame_on(False)
    ax[1].xaxis.set_visible(False)
    ax[1].yaxis.set_visible(False)
    
    def trace_axes_tunnel():
    # Tracé des axes du référentiel du tunnel
        ax[0].annotate("", xytext=(xmin, ymin), xy=(xmax, ymin), 
                      arrowprops=dict(arrowstyle="->",color='black',shrinkA=0,shrinkB=0)) # axe x
        ax[0].annotate( "$x$", xy=(xmax , ymin+.2), xytext=(xmax , ymin+.2) , va = "bottom", ha="right" )
        ax[0].annotate("", xytext=(xmin, ymin), xy=(xmin, ymax), 
                      arrowprops=dict(arrowstyle="->",color='black',shrinkA=0,shrinkB=0)) # axe ct
        ax[0].annotate( "$ct$", xy=(xmin+.2, ymax), xytext=(xmin+.2, ymax) , va = "top", ha="left" )
    
    def trace_axes_train(beta):
        # Tracé des axes du référentiel du train
        ax[0].annotate("", xytext=(xmin, ymin), xy=(xmax, xmax*beta), 
                  arrowprops=dict(arrowstyle="->",color='blue',shrinkA=0,shrinkB=0)) # axe x'
        ax[0].annotate( "$x'$", xy=(xmax , ymin+.2), xytext=(xmax , xmax*beta+.2) , va = "bottom", ha="right", color="blue")
        ax[0].annotate("", xytext=(xmin, ymin), xy=(ymax*beta, ymax), 
                  arrowprops=dict(arrowstyle="->",color='blue',shrinkA=0,shrinkB=0)) # axe ct'
        ax[0].annotate( "$ct'$", xy=(ymax*beta+.2, ymax), xytext=(ymax*beta+.2, ymax) , va = "top", ha="left", color="blue")

    trace_axes_tunnel()
    trace_axes_train(beta)
    
    def trace_event(beta):
        coords_ref_tunnel(beta)
        coords_ref_train(beta)
        # Marquage des événements A1 et B1
        ax[0].plot(A1.x, A1.ct, marker="o", markersize=5, markeredgecolor="red", markerfacecolor="red")
        ax[0].annotate( "$A_1$", xy=(A1.x+.2, A1.ct+.2), xytext=(A1.x+.2, A1.ct+.2) , va = "bottom", ha="left", color="red")
        ax[0].plot(B1.x, B1.ct, marker="o", markersize=5, markeredgecolor="red", markerfacecolor="red")
        ax[0].annotate( "$B_1$", xy=(B1.x+.2, B1.ct+.2), xytext=(B1.x+.2, B1.ct+.2) , va = "bottom", ha="left", color="red")
        # Coordonnées de A1 et B1 dans le référentiel du tunnel
        ax[0].plot([A1.x,A1.x],[ymin,A1.ct],'k--',linewidth=.5) # coordonnée x de A1
        ax[0].plot([B1.x,B1.x],[ymin,B1.ct],'k--',linewidth=.5) # coordonnée x de B1
        ax[0].plot([xmin,A1.x],[A1.ct,A1.ct],'k--',linewidth=.5) # coordonnée ct de A1
        ax[0].plot([xmin,B1.x],[B1.ct,B1.ct],'k--',linewidth=.5) # coordonnée ct de B1
        # Coordonnées de A1 et B1 dans le référentiel du train
        ax[0].plot([A1.x_prime,A1.x],[A1.x_prime*beta,A1.ct],'b--',linewidth=.5) # coordonnée x' de A1
        ax[0].plot([B1.x_prime,B1.x],[B1.x_prime*beta,B1.ct],'b--',linewidth=.5) # coordonnée x' de B1
        ax[0].plot([A1.ct_prime*beta,A1.x],[A1.ct_prime,A1.ct],'b--',linewidth=.5) # coordonnée ct de A1
        ax[0].plot([B1.ct_prime*beta,B1.x],[B1.ct_prime,B1.ct],'b--',linewidth=.5) # coordonnée ct de B1
        # Indication de la longueur du tunnel
        ax[0].annotate("", xytext=(A1.x, ymin-.5), xy=(B1.x, ymin-.5), 
                      arrowprops=dict(arrowstyle="<->",color='black',shrinkA=0,shrinkB=0))
        ax[0].annotate( "$\Delta x$", xy=((A1.x+B1.x)/2 , ymin-.7), xytext=((A1.x+B1.x)/2 , ymin-.7) , 
                     va = "top", ha="center", color="black")
        # Indication de la longueur du tunnel dans le référentiel du train
        ax[0].annotate("", xytext=(A1.x_prime, A1.x_prime*beta-.5), xy=(B1.x_prime, B1.x_prime*beta-.5), 
                      arrowprops=dict(arrowstyle="<->",color='blue',shrinkA=0,shrinkB=0))
        ax[0].annotate( "$\Delta x'$", xy=((A1.x_prime+B1.x_prime)/2 , (A1.x_prime+B1.x_prime)*beta/2-.7),
                       xytext=((A1.x_prime+B1.x_prime)/2 , (A1.x_prime+B1.x_prime)*beta/2-.7) , 
                     va = "top", ha="center", color="blue")
        
    trace_event(beta)
       
    def visu():
        # Dessiner le train
        ax[1].add_patch(Rectangle((train.visuA, ymin), train.visuB, ymin+1,
                     edgecolor = 'blue',
                     facecolor = 'blue',
                     fill=True,
                     lw=1))
        # Dessiner le tunnel
        ax[1].add_patch(Rectangle((tunnel.visuA, ymin), tunnel.visuB, ymin+1.5,
                     edgecolor = 'red',
                     facecolor = 'red',
                     fill=False,
                     lw=1))
        ax[1].annotate("", xytext=(xmin, ymin), xy=(xmax, ymin), 
                      arrowprops=dict(arrowstyle="->",color='black',shrinkA=0,shrinkB=0)) # axe x
        ax[1].annotate( "$x$", xy=(xmax , ymin+.2), xytext=(xmax , ymin+.2) , va = "bottom", ha="right" )
    
    pos_visu(beta,temps,referentiel) 
    visu()
    
    ax[0].plot([xmin,xmax],[sl_axct.val*A1.ct,sl_axct.val*A1.ct],'g-',linewidth=.5) # droite du temps

    def update_ct(val): 
        temps = sl_axct.val
        beta = sl_axv.val
        referentiel=radio.value_selected
        ax[1].patches.remove(ax[1].patches[0])
        ax[1].patches.remove(ax[1].patches[0])
        pos_visu(beta, temps, referentiel)
        visu()
        ax[0].lines.remove(ax[0].lines[10])
        if referentiel == "Référentiel du tunnel":
            ax[0].plot([xmin,xmax],[temps*A1.ct,temps*A1.ct],'g-',linewidth=.5) # droite du temps
        if referentiel == "Référentiel du train":
            cttemps_prime = temps*A1.ct_prime
            xtemps_prime=cttemps_prime*beta
            ax[0].plot([xtemps_prime,xmax],[cttemps_prime,(xmax-xtemps_prime)*beta+cttemps_prime],'g-',linewidth=.5) # droite du temps
        
    def update_v(val):
        temps = sl_axct.val
        beta = sl_axv.val
        ax[0].clear()
        ax[0].set_xlim(xmin0, xmax0)
        ax[0].set_ylim(ymin0, ymax0)
        ax[0].set_frame_on(False)
        ax[0].xaxis.set_visible(False)
        ax[0].yaxis.set_visible(False)
        trace_axes_train(beta)
        trace_axes_tunnel()
        coords_ref_tunnel(beta)
        coords_ref_train(beta)
        trace_event(beta)
        ax[1].patches.remove(ax[1].patches[0])
        ax[1].patches.remove(ax[1].patches[0])
        pos_visu(beta, temps, referentiel)
        visu()
        ax[0].plot([xmin,xmax],[temps*15,temps*15],'g-',linewidth=.5) # droite du temps
        
    def update_ref(label):
        update_ct(0)
        sl_axct.set_val(0)
       
    sl_axct.on_changed(update_ct)
    sl_axv.on_changed(update_v)
    radio.on_clicked(update_ref)
    
   
    # Tracé de la figure
    plt.show()


if __name__ =='__main__':
   plot_ani()